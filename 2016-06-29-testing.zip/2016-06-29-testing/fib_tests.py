from nose.tools import assert_equal

from fib import fib

# Write tests for two edge cases and a "normal" case
